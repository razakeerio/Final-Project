from flask import Flask, render_template_string
import random

app = Flask(__name__)

# -------------------------
# QUOTES DATABASE
# -------------------------

quotes = [
    "Believe in yourself and all that you are.",
    "Push yourself, because no one else is going to do it for you.",
    "Success doesn’t just find you. You have to go out and get it.",
    "Dream it. Wish it. Do it.",
    "Stay positive, work hard, make it happen.",
    "Great things never come from comfort zones.",
    "Don’t stop when you’re tired. Stop when you’re done.",
    "Doubt kills more dreams than failure ever will.",
    "Your only limit is your mind.",
    "Start where you are. Use what you have. Do what you can."
]

# -------------------------
# FUNCTION TO GET RANDOM QUOTE
# -------------------------

def get_random_quote():
    return random.choice(quotes)

# -------------------------
# HTML TEMPLATE
# -------------------------

def render_page(quote):
    return render_template_string(f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Motivational Quotes</title>
        <style>
            body {{
                background: linear-gradient(to right, #4facfe, #00f2fe);
                font-family: Arial;
                text-align: center;
                padding-top: 100px;
                color: white;
            }}
            .box {{
                background: rgba(0, 0, 0, 0.6);
                width: 500px;
                margin: auto;
                padding: 40px;
                border-radius: 15px;
            }}
            button {{
                margin-top: 20px;
                padding: 12px 25px;
                font-size: 16px;
                border: none;
                background: #ff9800;
                color: white;
                cursor: pointer;
                border-radius: 5px;
            }}
            button:hover {{
                background: #e68900;
            }}
        </style>
    </head>
    <body>
        <div class="box">
            <h2>🌟 Motivational Quote 🌟</h2>
            <p style="font-size:20px;">"{quote}"</p>
            <form method="GET">
                <button type="submit">Next Quote</button>
            </form>
        </div>
    </body>
    </html>
    """)

# -------------------------
# ROUTE
# -------------------------

@app.route("/")
def home():
    quote = get_random_quote()
    return render_page(quote)

# -------------------------
# RUN
# -------------------------

if __name__ == "__main__":
    app.run(debug=True)